package helper;

import android.view.View;

/**
 * Created by jmaldonado on 28/11/2017.
 */

public interface ItemClickListener {
    void onClick(View view, int position, boolean isLongClick);
}
